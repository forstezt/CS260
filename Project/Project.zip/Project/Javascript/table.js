    function ChangeColor(tableCell, highLight)
    {
    if (highLight)
    {
      tableCell.style.backgroundColor = '#0092DD';
    }
    else
    {
      tableCell.style.backgroundColor = '#D8D8D8';
    }
  }
